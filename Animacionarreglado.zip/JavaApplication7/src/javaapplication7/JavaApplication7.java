
package javaapplication7;
public class JavaApplication7 {
    public static void main(String[] args) {
    }
    
}
